class Animal

def set_nombre
	@nombre=nombre
end
def get_nombre
	return @nombre
end

def perroladra
	puts "Woawoa"
end
def gatomaulla
	puts "Miauuu"
end

end
mi_animal= Animal.New
mi_animal.set_nombre("Perro")
puts "El Perro ladra\ "#{mi_animal.perroladra}\"\n"
tu_animal= Animal.New
tu_animal.set_nombre("Gato")
puts "El Gato maulla\ "#{tu_animal.gatomaulla}\"\n"
