class Object
	def initialize(position_x=nil, position_y=nil, weigth=nil)
		@position_x=position_x
		@position_x=position_y
		@weigth=weigth
	end
	attr_accessor :position_x, position_y, weigth

class Weapon < Object
	des initialize(position_x=nil, position_y=nil, weigth=nil, damage=nil, success_msg=nil, failure_msg=nil)
		super(position_x, position_y, weigth)
		@damage=damage
		@success_msg= success_msg
		@failure_msg= failure_msg	
	end
	attr_accessor :damage, success_msg, failure_msg

class Agent <Object
	des initialize(position_x=nil, position_y=nil, weigth=nil, health=nil, strength=nil, name=nil, current_weapon=nil)
		super(position_x, position_y, weigth)
		@health= health
		@strength=strength
		@name=name
		@current_weapon=current_weapon	
	end
	attr_accessor :health, strength, name, current_weapon
end

class Enemy < Agent
	des initialize(health=nil, strength=nil, name=nil, current_weapon=nil, strategy_id=nil)
		super(health, strength, name, current_weapon)
		@strategy_id=strategy_id
	end
	attr_accessor :strategy_id
end

class Player < Agent
	des initialize(health=nil, strength=nil, name=nil, current_weapon=nil, id=nil)
		super(health, strength, name, current_weapon)
		@id=id
	end
	attr_accessor :id
end

