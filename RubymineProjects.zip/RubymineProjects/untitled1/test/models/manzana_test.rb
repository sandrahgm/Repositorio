require 'test_helper'

class ManzanaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
