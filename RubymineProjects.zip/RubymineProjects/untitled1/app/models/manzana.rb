class Manzana < ActiveRecord::Base
end
