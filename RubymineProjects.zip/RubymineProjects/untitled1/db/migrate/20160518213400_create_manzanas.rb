class CreateManzanas < ActiveRecord::Migration
  def change
    create_table :manzanas do |t|
      t.string :color

      t.timestamps null: false
    end
  end
end
