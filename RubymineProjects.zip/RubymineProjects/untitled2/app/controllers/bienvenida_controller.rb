class BienvenidaController < ApplicationController
  def index
  end
end
