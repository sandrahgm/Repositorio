#Autor Sandra Garcia
def area(b, a)
	base = (b * a)/2
	puts"#{b}*#{a}/2 = #{base}"
end
puts "Teclea la base: "
numero1= gets.chomp.to_i
puts "Teclea la altura: "
numero2= gets.chomp.to_i
area(numero1, numero2)